<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Laporan Absensi</title>
    <style>
        body{font-family:Arial,sans-serif;color:#54250f;padding:30px}
        h1{margin-bottom:4px}
        h2{margin:24px 0 8px}
        .summary{display:flex;gap:35px;margin:25px 0}
        .summary b{font-size:24px;display:block}
        table{width:100%;border-collapse:collapse;margin-bottom:24px}
        th,td{padding:9px;border:1px solid #f2d8c2;text-align:left;font-size:12px}
        th{background:#fff1e3;color:#a84316}
        @media print{body{padding:0}.member{break-inside:avoid}}
    </style>
</head>
<body>
    <h1>Laporan Absensi EKLESIA GROUP</h1>
    <?php if($showAll): ?>
        <p>Semua anggota · Periode <?php echo e($reports[0]['period_label'] ?? 'tidak ada anggota staff'); ?></p>
        <div class="summary">
            <div>Total hadir<b><?php echo e(collect($reports)->sum('present')); ?></b></div>
            <div>Total tidak hadir<b><?php echo e(collect($reports)->sum('absent')); ?></b></div>
            <div>Izin / sakit<b><?php echo e(collect($reports)->sum('leave')); ?></b></div>
            <div>Total telat<b><?php echo e(collect($reports)->sum('late')); ?> menit</b></div>
            <div>Total lembur<b><?php echo e(collect($reports)->sum('overtime')); ?> menit</b></div>
        </div>
        <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memberReport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <section class="member">
                <h2><?php echo e($memberReport['user']->name); ?></h2>
                <p>Hadir <?php echo e($memberReport['present']); ?> hari · Tidak hadir <?php echo e($memberReport['absent']); ?> hari · Izin / sakit <?php echo e($memberReport['leave']); ?> · Telat <?php echo e($memberReport['late']); ?> menit · Lembur <?php echo e($memberReport['overtime']); ?> menit</p>
                <table>
                    <thead><tr><th>Tanggal</th><th>Status</th><th>Masuk</th><th>Pulang</th><th>Telat</th><th>Lembur</th></tr></thead>
                    <tbody>
                        <?php $__currentLoopData = $memberReport['days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($day['date']->format('d/m/Y')); ?></td>
                                <td><?php echo e($day['dispensation'] ? 'Hadir (Dispen)' : ($day['attendance']?->check_in ? 'Hadir' : ($day['leave'] ? ucfirst($day['leave']->type) : ($day['future'] ? 'Belum berlangsung' : ($day['workday'] ? 'Tidak hadir' : 'Libur'))))); ?></td>
                                <td><?php echo e($day['attendance']?->check_in?->format('H:i') ?? '-'); ?></td>
                                <td><?php echo e($day['attendance']?->check_out?->format('H:i') ?? '-'); ?></td>
                                <td><?php echo e($day['attendance']?->late_minutes ?? 0); ?> menit</td>
                                <td><?php echo e($day['attendance']?->overtime_minutes ?? 0); ?> menit</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p><?php echo e($report['user']?->name); ?> · Periode <?php echo e($report['month']); ?></p>
        <div class="summary">
            <div>Hadir<b><?php echo e($report['present']); ?></b></div>
            <div>Tidak hadir<b><?php echo e($report['absent']); ?></b></div>
            <div>Izin / sakit<b><?php echo e($report['leave']); ?></b></div>
            <div>Total telat<b><?php echo e($report['late']); ?> menit</b></div>
            <div>Total lembur<b><?php echo e($report['overtime']); ?> menit</b></div>
        </div>
        <table>
            <thead><tr><th>Tanggal</th><th>Status</th><th>Masuk</th><th>Pulang</th><th>Telat</th><th>Lembur</th></tr></thead>
            <tbody>
                <?php $__currentLoopData = $report['days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($day['date']->format('d/m/Y')); ?></td>
                        <td><?php echo e($day['dispensation'] ? 'Hadir (Dispen)' : ($day['attendance']?->check_in ? 'Hadir' : ($day['leave'] ? ucfirst($day['leave']->type) : ($day['future'] ? 'Belum berlangsung' : ($day['workday'] ? 'Tidak hadir' : 'Libur'))))); ?></td>
                        <td><?php echo e($day['attendance']?->check_in?->format('H:i') ?? '-'); ?></td>
                        <td><?php echo e($day['attendance']?->check_out?->format('H:i') ?? '-'); ?></td>
                        <td><?php echo e($day['attendance']?->late_minutes ?? 0); ?> menit</td>
                        <td><?php echo e($day['attendance']?->overtime_minutes ?? 0); ?> menit</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\laragon\www\sdmeklesia\resources\views\admin\report-print.blade.php ENDPATH**/ ?>