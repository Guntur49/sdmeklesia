

<?php $__env->startSection('content'); ?>
<div class="topbar">
    <div>
        <div class="eyebrow">Manajemen penggajian</div>
        <h1>Gaji staff</h1>
        <p class="muted">Buat dan unduh slip gaji bulanan setiap staff.</p>
    </div>
    <span class="pill"><?php echo e($slips->count()); ?> slip · <?php echo e($month); ?></span>
</div>

<?php if($errors->any()): ?>
    <div class="alert error">
        <strong>Periksa kembali data slip gaji.</strong>
        <ul style="margin:8px 0 0;padding-left:20px">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<section class="card">
    <div class="eyebrow">Filter slip gaji</div>
    <h2>Pilih bulan dan staff</h2>
    <form method="get" action="<?php echo e(route('admin.payroll-slips.index')); ?>" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap">
        <label style="min-width:190px">Bulan
            <input type="month" name="month" value="<?php echo e($month); ?>" required>
        </label>
        <label style="min-width:220px">Staff
            <select name="user_id">
                <option value="">Semua staff</option>
                <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($person->id); ?>" <?php if($selectedUserId === $person->id): echo 'selected'; endif; ?>><?php echo e($person->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </label>
        <button class="btn ghost" type="submit">Tampilkan</button>
        <?php if($editingSlip): ?>
            <a class="btn ghost" href="<?php echo e(route('admin.payroll-slips.index', ['month' => $month, 'user_id' => $selectedUserId])); ?>">Slip baru</a>
        <?php endif; ?>
    </form>
</section>

<section class="card" style="margin-top:18px">
    <div class="eyebrow"><?php echo e($editingSlip ? 'Perbarui data' : 'Input baru'); ?></div>
    <h2><?php echo e($editingSlip ? 'Ubah slip gaji' : 'Tambahkan slip gaji'); ?></h2>
    <?php if($staff->isEmpty()): ?>
        <p class="muted">Belum ada staff yang terdaftar.</p>
    <?php else: ?>
        <form class="form-grid" method="post" action="<?php echo e(route('admin.payroll-slips.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-row">
                <label>Bulan gaji
                    <input type="month" name="month" data-payroll-month value="<?php echo e(old('month', $editingSlip?->month ?? $month)); ?>" required>
                </label>
                <label>Nama staff
                    <select name="user_id" data-payroll-staff required>
                        <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($person->id); ?>"
                                data-paid-days="<?php echo e($paidDaysByStaff[$person->id] ?? 0); ?>"
                                data-base-salary="<?php echo e($person->base_salary); ?>"
                                data-daily-attendance-allowance="<?php echo e($person->daily_attendance_allowance); ?>"
                                data-daily-meal-allowance="<?php echo e($person->daily_meal_allowance); ?>"
                                data-daily-transport-allowance="<?php echo e($person->daily_transport_allowance); ?>"
                                data-bpjs-subsidy="<?php echo e($person->bpjs_subsidy); ?>"
                                <?php if((int) old('user_id', $payrollUserId) === $person->id): echo 'selected'; endif; ?>
                            ><?php echo e($person->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
            </div>

            <p class="muted" style="margin:0">
                Jumlah hari dibayar: <strong data-paid-days-display><?php echo e($initialPaidDays); ?></strong> hari
                (check-in dan dispensasi; tanggal yang sama dihitung sekali).
            </p>

            <div class="grid grid-2">
                <section class="card">
                    <div class="eyebrow">Penerimaan</div>
                    <div class="form-grid">
                        <?php $__currentLoopData = \App\Models\PayrollSlip::EARNING_FIELDS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php ($isAutomatic = in_array($field, \App\Models\PayrollSlip::AUTOMATIC_EARNING_FIELDS, true)); ?>
                            <label><?php echo e($label); ?>

                                <input
                                    type="number"
                                    name="<?php echo e($field); ?>"
                                    value="<?php echo e($isAutomatic ? $automaticAmounts[$field] : old($field, $editingSlip?->getAttribute($field) ?? 0)); ?>"
                                    min="0"
                                    max="999999999999999"
                                    step="1"
                                    <?php if($isAutomatic): echo 'readonly'; endif; ?>
                                    required
                                >
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </section>
                <section class="card">
                    <div class="eyebrow">Potongan</div>
                    <div class="form-grid">
                        <?php $__currentLoopData = \App\Models\PayrollSlip::DEDUCTION_FIELDS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label><?php echo e($label); ?>

                                <input type="number" name="<?php echo e($field); ?>" value="<?php echo e(old($field, $editingSlip?->getAttribute($field) ?? 0)); ?>" min="0" max="999999999999999" step="1" required>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </section>
            </div>
            <button class="btn" type="submit"><?php echo e($editingSlip ? 'Simpan perubahan' : 'Simpan slip gaji'); ?></button>
        </form>
    <?php endif; ?>
</section>

<section class="card" style="margin-top:18px">
    <div class="topbar" style="margin-bottom:12px">
        <div>
            <div class="eyebrow">Arsip penggajian</div>
            <h2>Slip bulan <?php echo e($month); ?></h2>
        </div>
    </div>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr><th>Nama staff</th><th>Total penerimaan</th><th>Total potongan</th><th>Gaji diterima</th><th>Aksi</th></tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $slips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($slip->user->name); ?></td>
                        <td>Rp <?php echo e(number_format($slip->earningsTotal(), 0, ',', '.')); ?></td>
                        <td>Rp <?php echo e(number_format($slip->deductionsTotal(), 0, ',', '.')); ?></td>
                        <td><strong>Rp <?php echo e(number_format($slip->takeHomePay(), 0, ',', '.')); ?></strong></td>
                        <td>
                            <div style="display:flex;gap:8px">
                                <a class="btn ghost" href="<?php echo e(route('admin.payroll-slips.index', ['month' => $month, 'user_id' => $slip->user_id, 'edit' => $slip->id])); ?>">Ubah</a>
                                <a class="btn" href="<?php echo e(route('admin.payroll-slips.download', $slip)); ?>">Unduh Excel</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="muted">Belum ada slip gaji untuk bulan dan staff yang dipilih.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>

<script>
    const payrollStaffSelect = document.querySelector('[data-payroll-staff]');
    const payrollMonthInput = document.querySelector('[data-payroll-month]');

    if (payrollStaffSelect && payrollMonthInput) {
        const automaticFieldCalculators = {
            base_salary: (staff) => Number(staff.dataset.baseSalary),
            attendance: (staff) => Number(staff.dataset.dailyAttendanceAllowance) * Number(staff.dataset.paidDays),
            umkm: (staff) => Number(staff.dataset.dailyMealAllowance) * Number(staff.dataset.paidDays),
            transport: (staff) => Number(staff.dataset.dailyTransportAllowance) * Number(staff.dataset.paidDays),
            bpjs: (staff) => Number(staff.dataset.bpjsSubsidy),
        };

        const refreshAutomaticAmounts = () => {
            const staff = payrollStaffSelect.selectedOptions[0];
            const paidDays = Number(staff.dataset.paidDays);

            document.querySelector('[data-paid-days-display]').textContent = paidDays;

            for (const [field, calculate] of Object.entries(automaticFieldCalculators)) {
                const input = document.querySelector(`input[name="${field}"]`);
                input.value = calculate(staff);
                input.dispatchEvent(new Event('input', { bubbles: true }));
            }
        };

        payrollStaffSelect.addEventListener('change', refreshAutomaticAmounts);
        payrollMonthInput.addEventListener('change', () => {
            const url = new URL(window.location.href);
            url.searchParams.set('month', payrollMonthInput.value);
            url.searchParams.set('user_id', payrollStaffSelect.value);
            url.searchParams.delete('edit');
            window.location.assign(url);
        });

        refreshAutomaticAmounts();
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sdmeklesia\resources\views/admin/payroll-slips.blade.php ENDPATH**/ ?>